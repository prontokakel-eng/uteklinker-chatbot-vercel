import { detectLangLocal } from "../lib/detect-lang.js";

const samples = [
  "Do you need to seal Klinkerdäck®?",
  "How to clean Klinkerdäck®?",
  "Is Klinkerdäck® frost resistant?",
  "Behöver jag försegla Klinkerdäck®?",
  "Brauchen wir Klinkerdäck®?",
  "Kan man använda Klinkerdæk på altan?"
];

}
