// tests/chatPipeline-test.mjs

// ✅ Ladda env.local
import "../lib/load-env.js";
import { runChatPipeline } from "../lib/chatPipeline.js";

async function runTests() {
  const cases = [
    { input: "hej", desc: "SE greeting" },
    { input: "hi", desc: "EN greeting" },
    { input: "godmorgen", desc: "DA greeting" },
    { input: "guten abend", desc: "DE greeting" },
    { input: "12345 !!!", desc: "irrelevant nonsense" },
    { input: "Vilka mått gäller för plattorna?", desc: "FAQ-SE" },
    { input: "What sizes do you have available?", desc: "FAQ-EN" },
    { input: "asdfghjklqwerty", desc: "AI fallback nonsense" },
  ];

  console.log("📥 Loaded env vars");
  console.log("🔑 OPENAI_API_KEY =", process.env.OPENAI_API_KEY ? "[set]" : "[missing]");
  console.log("🔑 SHEET_ID =", process.env.SHEET_ID || "[missing]");
  console.log("🔑 GCP_PROJECT_ID =", process.env.GCP_PROJECT_ID || "[missing]");

  for (const { input, desc } of cases) {
    const res = await runChatPipeline(input, "127.0.0.1");
    console.log(`\n🔎 ${desc}`);
    console.log(`   Input: ${input}`);
    console.log(`   → Lang=${res.lang}, Source=${res.source}, Via=${res.via}`);
    console.log(`   → Reply: ${res.reply}`);
  }
}

runTests().catch(err => {
  console.error("💥 Test runner error:", err);
});
