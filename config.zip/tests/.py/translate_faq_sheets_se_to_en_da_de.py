import gspread
import pandas as pd
import time
import os
import json
from dotenv import load_dotenv
from openai import OpenAI

# ---------------------------------------------------
# 🔑 Läs miljövariabler från .env.local
# ---------------------------------------------------
load_dotenv(".env.local")

SHEET_ID = os.getenv("SHEET_ID_MAIN")
GCP_PROJECT_ID = os.getenv("GCP_PROJECT_ID")
GCP_CLIENT_EMAIL = os.getenv("GCP_CLIENT_EMAIL")
GCP_PRIVATE_KEY = os.getenv("GCP_PRIVATE_KEY")

if not all([SHEET_ID, GCP_PROJECT_ID, GCP_CLIENT_EMAIL, GCP_PRIVATE_KEY]):
    raise RuntimeError("❌ En eller flera miljövariabler saknas i .env.local")

# ---------------------------------------------------
# 🔐 Google Sheets auth via service account
# ---------------------------------------------------
creds = {
    "type": "service_account",
    "project_id": GCP_PROJECT_ID,
    "private_key_id": "dummy",
    "private_key": GCP_PRIVATE_KEY.replace("\\n", "\n"),
    "client_email": GCP_CLIENT_EMAIL,
    "client_id": "dummy",
    "token_uri": "https://oauth2.googleapis.com/token",
}

gc = gspread.service_account_from_dict(creds)
sh = gc.open_by_key(SHEET_ID)

# ---------------------------------------------------
# 🔧 OpenAI setup
# ---------------------------------------------------
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

# ---------------------------------------------------
# 📦 Cache för översättningar
# ---------------------------------------------------
CACHE_FILE = ".cache_faq_translate.json"
if os.path.exists(CACHE_FILE):
    with open(CACHE_FILE, "r", encoding="utf-8") as f:
        cache = json.load(f)
else:
    cache = {}

def save_cache():
    with open(CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(cache, f, ensure_ascii=False, indent=2)

# ---------------------------------------------------
# 🎨 Hämta färger/serier som ska skyddas från FAQ-extended
# ---------------------------------------------------
colors_file = os.path.join("faq-extended", "faq_colors_from_pronto_se_v2.json")
protected_words = set()
if os.path.exists(colors_file):
    with open(colors_file, "r", encoding="utf-8") as f:
        raw = json.load(f)
        if isinstance(raw, list):
            for item in raw:
                if isinstance(item, dict) and "answer_se" in item:
                    for line in item["answer_se"].splitlines():
                        line = line.strip()
                        if line.startswith("-"):
                            name = line[1:].split("–")[0].strip()
                            name = name.split("(")[0].strip()
                            if name:
                                protected_words.add(name)
else:
    print(f"⚠️ Varning: {colors_file} saknas, inga färger/serier skyddas.")

# ---------------------------------------------------
# 🌍 Översättningsfunktion
# ---------------------------------------------------
def translate_text(text, target_lang, row_id):
    """Försök hämta från cache, annars OpenAI."""
    key = f"{text}::{target_lang}"
    if key in cache:
        return cache[key], "CACHE"

    # Skydda produktnamn/färger
    for word in protected_words:
        if word in text:
            cache[key] = text
            return text, "PROTECTED"

    # Översätt via OpenAI
    prompt = f"Translate this FAQ text into {target_lang}. Keep brand names, product series, and colors unchanged:\n\n{text}"
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1,
    )
    translated = response.choices[0].message.content.strip()
    cache[key] = translated
    return translated, "OPENAI"

# ---------------------------------------------------
# 📝 Bearbeta FAQ_SE och fyll i EN/DA/DE
# ---------------------------------------------------
def process_sheet(limit=None):
    ws_se = sh.worksheet("FAQ_SE")
    data = ws_se.get_all_records()

    ws_en = sh.worksheet("FAQ_EN")
    ws_da = sh.worksheet("FAQ_DA")
    ws_de = sh.worksheet("FAQ_DE")

    updates_en, updates_da, updates_de = [], [], []

    total = len(data)
    stats = {"CACHE": 0, "PROTECTED": 0, "OPENAI": 0}

    for idx, row in enumerate(data):
        if limit and idx >= limit:
            break

        # Fallback: om "answer_full_se" inte finns → använd "answer_se"
        q_se = row.get("question_se", "")
        a_se = row.get("answer_se", "")
        a_full_se = row.get("answer_full_se", a_se)

        for lang, updates, ws in [
            ("English", updates_en, ws_en),
            ("Danish", updates_da, ws_da),
            ("German", updates_de, ws_de),
        ]:
            tq, src1 = translate_text(q_se, lang, idx); stats[src1] += 1
            ta, src2 = translate_text(a_se, lang, idx); stats[src2] += 1
            taf, src3 = translate_text(a_full_se, lang, idx); stats[src3] += 1

            updates.append([tq, ta, taf, f"{src1}/{src2}/{src3}"])

        # 🔎 Progress: var 20:e rad
        if (idx + 1) % 20 == 0 or (idx + 1) == total:
            print(f"✅ {idx+1} av {total} rader: CACHE={stats['CACHE']}, PROTECTED={stats['PROTECTED']}, OPENAI={stats['OPENAI']}")
            save_cache()

    # Batch update tillbaka till Google Sheets
    def write_updates(ws, updates, lang):
        ws.clear()
        ws.append_row([f"question_{lang[:2].lower()}", f"answer_{lang[:2].lower()}", f"answer_full_{lang[:2].lower()}", "Source"])
        ws.append_rows(updates)  # allt i ett anrop, ingen sleep

    write_updates(ws_en, updates_en, "English")
    write_updates(ws_da, updates_da, "Danish")
    write_updates(ws_de, updates_de, "German")

    save_cache()
    print("✅ Translation finished and written to sheets.")

# ---------------------------------------------------
# 🚀 Main entry
# ---------------------------------------------------
def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, help="Limit antal rader för test")
    args = parser.parse_args()

    process_sheet(limit=args.limit)

if __name__ == "__main__":
    main()
