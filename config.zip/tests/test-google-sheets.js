import "../lib/load-env.js";
import { google } from "googleapis";
async function main() {
  console.log("🔍 Testar Google Sheets FAQ_SE...");
  try {
    const auth = new google.auth.GoogleAuth({
      credentials: {
        type: "service_account",
        project_id: process.env.GCP_PROJECT_ID,
        private_key_id: process.env.GCP_PRIVATE_KEY_ID,
        private_key: (process.env.GCP_PRIVATE_KEY || "")
          .replace(/\\n/g, "\n")
          .replace(/"/g, "")
          .trim(),
        client_email: process.env.GCP_CLIENT_EMAIL,
        client_id: process.env.GCP_CLIENT_ID,
      },
      scopes: ["https://www.googleapis.com/auth/spreadsheets.readonly"],
    });
    const sheets = google.sheets({ version: "v4", auth });
    const sheetName = "FAQ_SE";
    const range = `${sheetName}!A:B`;
    console.log(`📄 Hämtar från Sheet ID: ${process.env.SHEET_ID}, range: ${range}`);
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: process.env.SHEET_ID,
      range,
    });
    const rows = response.data.values || [];
    if (!rows.length) {
      console.error("⚠️ Inga rader hittades i FAQ_SE");
    } else {
      console.log(`✅ Hittade ${rows.length} rader i FAQ_SE`);
      console.log("👀 Första 3 raderna:");
      rows.slice(0, 3).forEach((row, i) => {
        console.log(`${i}: Q="${row[0]}", A="${row[1]}"`);
      });
    }
  } catch (err) {
    console.error("❌ Sheets-test fel:", err.message);
  }
}
main();