// lib/faq-cache.js
import fs from "fs";
import path from "path";
import { loadAllFaqData, loadAllLookups } from "./faq-sheets.js"; 
import { logMessage } from "./logger.js";   // ✅ central logg

const CACHE_FILE = path.join(process.cwd(), "faq-cache.json");

// Standardstruktur
let faqCache = {
  FAQ: { SE: [], DA: [], DE: [], EN: [] },
  LOOKUP: { SE: [], DA: [], DE: [], EN: [] },
};

/**
 * Hämta cache (i minnet)
 */
export function getFaqCache() {
  return faqCache;
}

/**
 * Initiera FAQ-cache (hämtar från Sheets och sparar till fil)
 */
export async function initFaqCache(caller = "unknown") {
  try {
    const rawFaq = await loadAllFaqData();
    const rawLookup = await loadAllLookups();

    faqCache = {
      FAQ: normalizeFaq(rawFaq),
      LOOKUP: normalizeLookup(rawLookup),
    };

    fs.writeFileSync(CACHE_FILE, JSON.stringify(faqCache, null, 2), "utf8");
    logMessage(
      "faq-cache.log",
      `✅ FAQ-cache laddad och sparad (caller: ${caller}): ${JSON.stringify(summary(faqCache))}`
    );
    return faqCache;
  } catch (err) {
    logMessage(
      "faq-cache.log",
      `⚠️ Kunde inte ladda FAQ/LOOKUP från Sheets (caller: ${caller}): ${err.message}`
    );
    return faqCache;
  }
}

/**
 * Försök ladda cache från fil
 */
export function loadFaqCache(caller = "unknown") {
  if (fs.existsSync(CACHE_FILE)) {
    try {
      const raw = fs.readFileSync(CACHE_FILE, "utf8");
      const parsed = JSON.parse(raw);

      faqCache = {
        FAQ: normalizeFaq(parsed.FAQ || {}),
        LOOKUP: normalizeLookup(parsed.LOOKUP || {}),
      };

      logMessage(
        "faq-cache.log",
        `✅ FAQ-cache laddad från fil (caller: ${caller}): ${JSON.stringify(summary(faqCache))}`
      );
    } catch (err) {
      logMessage(
        "faq-cache.log",
        `⚠️ Kunde inte läsa cachefil (caller: ${caller}): ${err.message}`
      );
    }
  } else {
    logMessage(
      "faq-cache.log",
      `🚀 Ingen cache hittades (caller: ${caller}), kör initFaqCache istället.`
    );
  }
  return faqCache;
}

/**
 * Normalisera FAQ: mappar om {q,a} → {question,answer}
 */
function normalizeFaq(raw) {
  const out = { SE: [], DA: [], DE: [], EN: [] };
  for (const lang of Object.keys(out)) {
    out[lang] = (raw[lang] || []).map((row) => ({
      question: row.question ?? row.q ?? "",
      answer: row.answer ?? row.a ?? "",
    }));
  }
  return out;
}

/**
 * Normalisera LOOKUP: platta strängar
 */
function normalizeLookup(raw) {
  const out = { SE: [], DA: [], DE: [], EN: [] };
  for (const lang of Object.keys(out)) {
    out[lang] = (raw[lang] || []).map((kw) => String(kw).trim().toLowerCase());
  }
  return out;
}

/**
 * Summera antal poster i FAQ + LOOKUP
 */
function summary(cache) {
  return {
    FAQ: {
      SE: cache.FAQ.SE?.length || 0,
      DA: cache.FAQ.DA?.length || 0,
      DE: cache.FAQ.DE?.length || 0,
      EN: cache.FAQ.EN?.length || 0,
    },
    LOOKUP: {
      SE: cache.LOOKUP.SE?.length || 0,
      DA: cache.LOOKUP.DA?.length || 0,
      DE: cache.LOOKUP.DE?.length || 0,
      EN: cache.LOOKUP.EN?.length || 0,
    },
  };
}
