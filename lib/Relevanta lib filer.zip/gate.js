/**
 * ============================================================
 *  GATE PIPELINE (språklös)
 *
 *  Syfte:
 *   - Första linjen i chat.js
 *   - Hanterar blockering innan språkdetection
 *
 *  📌 Viktigt:
 *   - gate.js returnerar { filtered, reason, via }
 *   - detect-lang.js körs ALDRIG om filtered=true
 * ============================================================
 */

import { normalizeMessage } from "./utils-text.js";
import { containsWhitelistWord, containsBlacklistWord, isGibberish } from "./filters.js";
import { checkRateLimit } from "./rate-limiter.js";

export function runGate(message, ip = "anon") {
  const norm = normalizeMessage(message);
  
    // 🚫 Long text filter – lägg tidigt
  const MAX_LEN = 400;
  if (norm.length > MAX_LEN) {
    return {
      filtered: true,
      reason: `🚫 För lång fråga (${norm.length} tecken)`,
      via: "long-text",
    };
  }
  // 0️⃣ Rate-limit check (fast + slow via rate-limiter.js)
  const rl = checkRateLimit(ip);
  if (rl.limited) {
    return {
      filtered: true,
      reason: rl.reason,
      via: rl.type ? `rate-limit-${rl.type}` : "rate-limit",
    };
  }

  // 1️⃣ Whitelist → alltid släpp igenom (ALL-läget, språklöst)
  if (containsWhitelistWord(norm, "ALL")) {
    return {
      filtered: false,
      reason: "✅ Whitelist override",
      via: "whitelist-ALL",
    };
  }

  // 2️⃣ Blacklist → hård block (ALL-läget, språklöst)
  if (containsBlacklistWord(norm, "ALL")) {
    return {
      filtered: true,
      reason: "🚫 Din fråga innehåller blockerade ord.",
      via: "blacklist-ALL",
    };
  }

  // 3️⃣ Språk-specifika whitelist/blacklist (extra debugnivå)
  for (const lang of ["SE", "EN", "DA", "DE"]) {
    if (containsWhitelistWord(norm, lang)) {
      return {
        filtered: false,
        reason: `✅ Whitelist override [${lang}]`,
        via: `whitelist-${lang}`,
      };
    }
    if (containsBlacklistWord(norm, lang)) {
      return {
        filtered: true,
        reason: `🚫 Din fråga innehåller blockerade ord [${lang}].`,
        via: `blacklist-${lang}`,
      };
    }
  }

  // 4️⃣ Gibberish → blockera
  if (isGibberish(norm)) {
    return {
      filtered: true,
      reason: "🚫 Din fråga ser ut som gibberish.",
      via: "gibberish",
    };
  }

  // 5️⃣ För kort text
  if (norm.length < 2) {
    return {
      filtered: true,
      reason: "🚫 För kort fråga.",
      via: "short-text",
    };
  }
  // 🚫 Long text filter
  if (norm.length > 400) {
    return { filtered: true, reason: "long", via: "gate-long" };
  }

  
  // ✅ Annars → släpp igenom
  return { filtered: false, reason: "OK", via: "pass" };
}
