// lib/filters.js
import path from "path";
import { fileURLToPath } from "url";
import stringSimilarity from "string-similarity";
import { normalizeMessage } from "./utils-text.js";
import wordLists from "../config/BL-WL-words-list.json" with { type: "json" };

// ESM-safe __dirname (ifall vi behöver andra reads senare)
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function escapeRegex(s) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// --- Build helper ---
function buildList(type, lang = "ALL") {
  const section = wordLists[type] || {};

  // ALL är alltid med, och vi lägger till språkets lista om den finns
  const merged = [
    ...(section.ALL || []),
    ...(lang && lang !== "ALL" ? section[lang] || [] : []),
  ];

  return merged
    .map((s) => String(s).toLowerCase())
    .filter(Boolean);
}
// filters.js

// ✅ Hälsningsfraser per språk
const greetings = {
  SE: ["hej", "hejhej", "tjena", "godmorgon", "god kväll", "godmiddag", "god eftermiddag"],
  EN: ["hi", "hello", "hey", "good morning", "good evening", "good afternoon"],
  DA: ["hej", "hejhej", "godmorgen", "godaften", "goddag"],
  DE: ["hallo", "hi", "guten morgen", "guten abend", "guten tag"]
};

// ✅ Standardsvar för hälsningar
const greetingReplies = {
  SE: "Hej! Vad kan vi hjälpa dig med?",
  EN: "Hello! How can we help you?",
  DA: "Hej! Hvordan kan vi hjælpe dig?",
  DE: "Hallo! Wie können wir Ihnen helfen?"
};

// ------------------------------------------------------------
// 🟢 Greeting check
// ------------------------------------------------------------
export function checkGreeting(input, detectedLang = "SE") {
  const txt = input.trim().toLowerCase();

  // 1. Kolla i listan för detekterat språk
  const langList = greetings[detectedLang] || [];
  if (langList.some(g => txt.startsWith(g))) {
    return { handled: true, reply: greetingReplies[detectedLang] };
  }

  // 2. Om inget hittades, kolla i ALLA språklistor
  for (const [lang, list] of Object.entries(greetings)) {
    if (list.some(g => txt.startsWith(g))) {
      return { handled: true, reply: greetingReplies[lang] };
    }
  }

  return { handled: false };
}

// ------------------------------------------------------------
// 🟡 Relevance check
// ------------------------------------------------------------
export function checkRelevance(input, detectedLang = "SE") {
  const txt = input.trim().toLowerCase();

  // Enkel heuristik: för kort, bara siffror/tecken → irrelevant
  if (txt.length < 3 || /^[\d\W]+$/.test(txt)) {
    return {
      handled: true,
      reply: {
        SE: "Din fråga verkar inte vara relaterad till våra produkter. Vänligen omformulera frågan.",
        EN: "Your question doesn’t seem to relate to our products. Please rephrase your question.",
        DA: "Dit spørgsmål ser ikke ud til at være relateret til vores produkter. Venligst omformuler spørgsmålet.",
        DE: "Ihre Frage scheint nicht mit unseren Produkten zusammenzuhängen. Bitte formulieren Sie die Frage um."
      }[detectedLang] || "Din fråga verkar inte vara relaterad till våra produkter. Vänligen omformulera frågan."
    };
  }

  return { handled: false };
}

// ------------------------------------------------------------
// 🔵 Här kan du exportera andra filterfunktioner som redan finns
// ------------------------------------------------------------

// Exempel (om du har fler filterregler)
// export function someOtherFilter(input) {
//   ...
// }

// --- Whitelist check (fuzzy + exact) ---
export function containsWhitelistWord(message, lang = "SE", threshold = 0.8) {
  if (!message || typeof message !== "string") return false;
  const msg = normalizeMessage(message);
  const words = msg.split(/\s+/);

  const list = buildList("WHITELIST", lang);
  if (!list.length) return false;

  // 1. Direktträff
  for (const word of list) {
    if (msg.includes(word)) {
      console.log(`✅ WL exact match [${lang}]`, { word, message });
      return true;
    }
  }

  // 2. Fuzzyträffar
  try {
    for (const word of words) {
      if (word.length < 3) continue;
      const matches = stringSimilarity.findBestMatch(word, list);
      if (matches.bestMatch.rating >= threshold) {
        console.log(`✅ WL fuzzy match [${lang}]`, { word, match: matches.bestMatch, message });
        return true;
      }
    }
  } catch (e) {
    console.error("⚠️ containsWhitelistWord fuzzy check failed:", e);
    return false;
  }

  return false;
}


// --- Blacklist check (regex + fuzzy) ---
export function containsBlacklistWord(message, lang = "ALL", threshold = 0.95) {
  if (!message || typeof message !== "string") return false;
  const msg = normalizeMessage(message);
  const words = msg.split(/\s+/).filter(Boolean);

  const list = buildList("BLACKLIST", lang);
  if (!list.length) return false;

  // 1) Exact whole-word match
  for (const bad of list) {
    const re = new RegExp(`\\b${escapeRegex(bad)}\\b`, "i");
    if (re.test(msg)) {
      console.log(`🔒 BL exact match [${lang}]`, { bad, message });
      return true;
    }
  }

  // 2) Fuzzy (säkrare)
  try {
    for (const word of words) {
      if (word.length < 3) continue;
      const matches = stringSimilarity.findBestMatch(word, list);
      const best = matches.bestMatch;
      if (best.rating >= threshold && best.target.length >= 3) {
        console.log(`🔒 BL fuzzy match [${lang}]`, { word, match: best, message });
        return true;
      }
    }
  } catch (e) {
    console.error("⚠️ containsBlacklistWord fuzzy failed:", e);
    return false;
  }

  return false;
}


// --- Gibberish detection ---
export function isGibberish(message) {
  const msg = normalizeMessage(message);
  const words = msg.split(/\s+/).filter(Boolean);

  if (words.length < 2 && msg.length > 12) {
    console.log("🤪 Gibberish (långt nonsensord)", { message });
    return true;
  }
  if (words.length > 0 && words.every((w) => w.length > 10)) {
    console.log("🤪 Gibberish (alla jättelånga ord)", { message });
    return true;
  }
  if ((msg.match(/[^a-zåäö]/gi) || []).length / Math.max(1, msg.length) > 0.5) {
    console.log("🤪 Gibberish (>50% icke-bokstäver)", { message });
    return true;
  }

  return false;
}
