// /lib/rate-limiter.js
import LRU from "lru-cache";

const requests = new LRU({ max: 10000, ttl: 60 * 1000 }); // 1 min TTL

// Slow limiter
const DEFAULT_LIMIT = parseInt(process.env.RATE_LIMIT || "7", 10);
const DEFAULT_WINDOW = parseInt(process.env.RATE_LIMIT_WINDOW || "60000", 10);

// Fast limiter
const FAST_LIMIT = parseInt(process.env.RATE_LIMIT_FAST || "3", 10);
const FAST_WINDOW = parseInt(process.env.RATE_LIMIT_FAST_WINDOW || "5000", 10);

// Whitelist
const WHITELIST_IPS = (process.env.RATE_LIMIT_WHITELIST || "")
  .split(",")
  .map((ip) => ip.trim())
  .filter(Boolean);

function check(ip, limit, windowMs) {
  const now = Date.now();
  const history = requests.get(ip) || [];
  const recent = history.filter((t) => now - t < windowMs);
  recent.push(now);
  requests.set(ip, recent);
  return recent.length > limit;
}

export function checkRateLimit(ip = "anon") {
  // 🛡️ Test mode bypass
  if (process.env.TEST_MODE === "true") return { limited: false };

  // 🛡️ Whitelist bypass
  if (WHITELIST_IPS.includes(ip)) return { limited: false };

  // 🚀 Fast limiter först
  if (check(ip + "-fast", FAST_LIMIT, FAST_WINDOW)) {
    const reason = `🚫 För många requests (FAST: max ${FAST_LIMIT} per ${FAST_WINDOW / 1000}s).`;
    console.warn(`[RateLimiter] FAST Blocked IP=${ip}`);
    return { limited: true, reason, type: "fast" };
  }

  // 🐢 Sedan slow limiter
  if (check(ip + "-slow", DEFAULT_LIMIT, DEFAULT_WINDOW)) {
    const reason = `🚫 För många requests (SLOW: max ${DEFAULT_LIMIT} per ${DEFAULT_WINDOW / 1000}s).`;
    console.warn(`[RateLimiter] SLOW Blocked IP=${ip}`);
    return { limited: true, reason, type: "slow" };
  }

  return { limited: false };
}
