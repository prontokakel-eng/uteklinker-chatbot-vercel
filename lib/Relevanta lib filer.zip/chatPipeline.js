// lib/chatPipeline.js
import { runGate } from "./gate.js";
import { detectLangCore } from "./detect-lang-core.js";   // ✅ språkdetektion
import { searchFaq } from "./faq-data.js";
import { handleFaqDialog } from "./faq-dialog.js";        // ✅ dialoghantering
import { askAI } from "./ai-fallback.js";                 // ✅ GPT-fallback
import { logMessage } from "./logger.js";                 // ✅ central logg
import { randomUUID } from "crypto";                      // ✅ unik ID per fråga

/**
 * Huvudpipeline för chatten
 * @param {object} req - request-objekt (med body.text)
 * @param {object} res - response-objekt (ej alltid använt här)
 */
export async function chatPipeline(req, res) {
  const id = randomUUID().slice(0, 5);          // kort UUID för spårning
  const clean = req.body?.text?.trim() || "";   // normaliserad text

  // === Gate & Filters ===
  const gateResult = runGate(clean, req.ip || "anon");
  if (gateResult.filtered) {
    return {
      lang: "FILTER",
      reply: "(no reply)",
      via: gateResult.via,
      reason: gateResult.reason,
    };
  }

  // 🚫 Empty input
  if (!clean) {
    const msg = {
      lang: "SE",
      reply: "⚠️ Ingen text angiven.",
      source: "SYSTEM",
      via: "system",
    };
    logMessage(
      "chat-pipeline.log",
      `[id=${id}] 🚫 Empty input → ${JSON.stringify(msg)}`
    );
    return msg;
  }

  // 2️⃣ Språkdetektion
  const langRes = await detectLangCore(clean);
  const lang = langRes.lang || "SE";
  logMessage(
    "chat-pipeline.log",
    `[id=${id}] 🌐 Lang detect: "${clean}" → lang=${langRes.lang}, via=${langRes.via}, conf=${langRes.confidence}`
  );

  // 3️⃣ FAQ Lookup
  const faqMatches = searchFaq(lang, clean, { limit: 1 });
  if (faqMatches && faqMatches.length > 0) {
    const best = faqMatches[0]; // ✅ ta bästa träffen
    const msg = {
      lang,
      reply: handleFaqDialog({}, clean, best.answer, lang), // ✅ dialoglogik
      source: "FAQ",
      via: "faq",
    };
    logMessage(
      "chat-pipeline.log",
      `[id=${id}] ✅ FAQ hit: "${clean}" → "${(best.answer || "").slice(0, 80)}..."`
    );
    return msg;
  }

  // 4️⃣ AI fallback (GPT-4o)
  const aiReply = await askAI(clean, lang);
  const msg = {
    lang,
    reply: aiReply,
    source: "AI_FALLBACK",
    via: "ai",
  };
  logMessage(
    "chat-pipeline.log",
    `[id=${id}] 🤖 AI fallback: "${clean}" (lang=${langRes.lang}, via=${langRes.via}) → "${(aiReply || "").slice(0, 80)}..."`
  );
  return msg;
}
