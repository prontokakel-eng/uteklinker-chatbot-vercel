// /lib/faq-sheets.js
import { google } from "googleapis";
import { validateEnv } from "./env-check.js";

let sheetsClient;

/**
 * Hämtar eller initierar en Google Sheets-klient
 */
export async function getSheetsClient(caller = "unknown") {
  if (sheetsClient) {
    console.log(`♻️ Google Sheets client reused (called from: ${caller})`);
    return sheetsClient;
  }

  // ✅ Kolla miljövariabler innan vi initierar
  validateEnv([
    ["GOOGLE_SERVICE_ACCOUNT_EMAIL", "GCP_CLIENT_EMAIL"],
    ["GOOGLE_SERVICE_ACCOUNT_KEY", "GCP_PRIVATE_KEY"],
    ["SHEET_ID_MAIN", "SHEET_ID"],
  ]);

  const email = process.env.GCP_CLIENT_EMAIL || process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL;
  const key = process.env.GCP_PRIVATE_KEY || process.env.GOOGLE_SERVICE_ACCOUNT_KEY;
  const sheetId = process.env.SHEET_ID_MAIN || process.env.SHEET_ID;

  console.log("[faq-sheets] Init Sheets client med env:", {
    email: email ? "✅" : "❌",
    key: key ? "✅" : "❌",
    sheetId: sheetId ? "✅" : "❌",
  });

  const auth = new google.auth.JWT({
    email,
    key: key?.replace(/\\n/g, "\n"),
    scopes: ["https://www.googleapis.com/auth/spreadsheets.readonly"],
  });

  sheetsClient = google.sheets({ version: "v4", auth });
  console.log(`🔑 Google Sheets client initialized (first call from: ${caller})`);

  return sheetsClient;
}

// === FAQ (FAQ_SE, FAQ_EN, FAQ_DA, FAQ_DE) ===
export async function loadFaqFromSheet(lang = "SE", caller = "loadFaqFromSheet") {
  const sheets = await getSheetsClient(caller);
  const sheetName = `FAQ_${lang}`;
  const range = `${sheetName}!A:B`;

  const response = await sheets.spreadsheets.values.get({
    spreadsheetId: process.env.SHEET_ID_MAIN || process.env.SHEET_ID,
    range,
  });

  const rows = response.data.values || [];
  return rows.slice(1).map(([q = "", a = ""]) => ({
    q: String(q).trim(),
    a: String(a).trim(),
  }));
}

// === Lookup (SE_FULL_LOOKUP, EN_FULL_LOOKUP, DA_FULL_LOOKUP, DE_FULL_LOOKUP) ===
export async function loadLookupFromSheet(lang = "SE", caller = "loadLookupFromSheet") {
  const sheets = await getSheetsClient(caller);
  const sheetName = `${lang}_FULL_LOOKUP`;
  const range = `${sheetName}!A:A`;

  const response = await sheets.spreadsheets.values.get({
    spreadsheetId: process.env.SHEET_ID_MAIN || process.env.SHEET_ID,
    range,
  });

  const rows = response.data.values || [];
  return rows
    .slice(1)
   .map(([kw = ""]) => ({ keyword: String(kw).trim().toLowerCase() }))
   .filter((r) => r.keyword);
}

// === Ladda alla FAQ (alla språk) ===
export async function loadAllFaqData() {
  const langs = ["SE", "EN", "DA", "DE"];
  const result = {};

  for (const lang of langs) {
    try {
      result[lang] = await loadFaqFromSheet(lang, "loadAllFaqData");
      console.log(`[faq-sheets] ✅ Loaded FAQ_${lang}: ${result[lang].length} rows`);
    } catch (err) {
      console.error(`[faq-sheets] ⚠️ Failed to load FAQ_${lang}:`, err.message);
      result[lang] = [];
    }
  }
  return result;
}

// === Ladda alla Lookups (alla språk) ===
export async function loadAllLookups() {
  const langs = ["SE", "EN", "DA", "DE"];
  const result = {};

  for (const lang of langs) {
    try {
      result[lang] = await loadLookupFromSheet(lang, "loadAllLookups");
      console.log(`[faq-sheets] ✅ Loaded ${lang}_FULL_LOOKUP: ${result[lang].length} keywords`);
    } catch (err) {
      console.error(`[faq-sheets] ⚠️ Failed to load ${lang}_FULL_LOOKUP:`, err.message);
      result[lang] = [];
    }
  }
  return result;
}
// === Ladda både FAQ och FULL_LOOKUP (för initFaqData) ===
export async function loadAllFaqAndLookups() {
  const faqData = await loadAllFaqData();
  const lookups = await loadAllLookups();
  return {
    ...faqData,
    SE_FULL_LOOKUP: lookups.SE,
    EN_FULL_LOOKUP: lookups.EN,
    DA_FULL_LOOKUP: lookups.DA,
    DE_FULL_LOOKUP: lookups.DE,
  };
}
