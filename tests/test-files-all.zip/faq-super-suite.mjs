import "../lib/load-env.js";
// tests/faq-super-suite.mjs
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { google } from "googleapis";
import stringSimilarity from "string-similarity";
import { getFaqByLang, getFaqCache } from "./../lib/faq-cache.js";
import { normalizeMessage } from "./../lib/utils.js";
import { detectLangLocal } from "./../lib/detect-lang.js";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const LOG_DIR = path.join(__dirname, "../logs");
const LOG_FILE = path.join(LOG_DIR, "super-suite.log");
if (!fs.existsSync(LOG_DIR)) fs.mkdirSync(LOG_DIR, { recursive: true });
let mismatchCount = 0;
function logChat(message, expectedLang, source, reply) {
  const detected = detectLangLocal(message, expectedLang);
  const line =
    `[${new Date().toISOString()}] (expected=${expectedLang}, detected=${detected.lang}/${detected.method}, source=${source})\n` +
    `Q: ${message}\n→ ${reply}\n\n`;
  fs.appendFileSync(LOG_FILE, line, "utf8");
  if (expectedLang !== detected.lang) {
    mismatchCount++;
    console.warn(
      `⚠️ Språk-mismatch: expected=${expectedLang}, detected=${detected.lang} (${detected.method}) for Q="${message}"`
    );
  }
}
function ok(msg) { console.log("✅", msg); }
function fail(msg) { console.error("❌", msg); process.exitCode = 1; }
// --- Google Sheets ---
function getAuth() {
  return new google.auth.GoogleAuth({
    credentials: {
      type: "service_account",
      project_id: process.env.GCP_PROJECT_ID,
      private_key_id: process.env.GCP_PRIVATE_KEY_ID,
      private_key: process.env.GCP_PRIVATE_KEY?.replace(/\\n/g, "\n"),
      client_email: process.env.GCP_CLIENT_EMAIL,
      client_id: process.env.GCP_CLIENT_ID,
    },
    scopes: ["https://www.googleapis.com/auth/spreadsheets"],
  });
}
async function getSheets() {
  const auth = await getAuth();
  return google.sheets({ version: "v4", auth });
}
const SHEET_ID = process.env.SHEET_ID;
const TEST_TAB = "Test";
const LANGS = ["SE", "EN", "DA", "DE"];
// --- Helper: plocka 4 frågor per språk ---
function pickNPerLang(FAQ_CACHE, n = 4) {
  const items = [];
  for (const lang of LANGS) {
    const list = FAQ_CACHE[lang] || [];
    if (list.length < n) throw new Error(`För få rader i FAQ_${lang}`);
    for (let i = 0; i < n; i++) {
      const row = list[i];
      items.push({ lang, question: String(row.question || ""), answer: String(row.answer || "") });
    }
  }
  return items;
}
// --- Helper: skriv till Test-flik ---
async function appendRowsToTest(rows) {
  if (!rows.length) return;
  const sheets = await getSheets();
  await sheets.spreadsheets.values.append({
    spreadsheetId: SHEET_ID,
    range: `${TEST_TAB}!A:B`,
    valueInputOption: "RAW",
    requestBody: { values: rows },
  });
}
// --- Helper: hämta rader från Test-flik ---
async function readTestSheet() {
  const sheets = await getSheets();
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId: SHEET_ID,
    range: `${TEST_TAB}!A:B`,
  });
  return res.data.values || [];
}
// --- Steg 1–10 ---
async function runSuperSuite() {
  const FAQ_CACHE = await getFaqCache(true);
  const items = pickNPerLang(FAQ_CACHE, 4);
  ok(`Valde ${items.length} frågor (${LANGS.join(", ")})`);
  // 2) Kolla att 16 svar matchar
  for (const it of items) {
    const questions = (await getFaqByLang(it.lang)).map(f => normalizeMessage(f.question));
    const matches = stringSimilarity.findBestMatch(normalizeMessage(it.question), questions);
    const reply = (await getFaqByLang(it.lang))[matches.bestMatchIndex].answer;
    logChat(it.question, it.lang, "FAQ", reply);
    if (!reply) fail(`Ingen match för ${it.lang} :: ${it.question}`);
  }
  ok("Alla 16 frågor hittade svar i FAQ");
  // 3) Uppdatera svar
  const rows1 = items.map(it => [it.question, `${it.answer} xxx-${it.lang.toLowerCase()}`]);
  await appendRowsToTest(rows1);
  ok("16 uppdaterade svar sparade i Test-flik");
  // 4) Verifiera svar
  const testRows1 = await readTestSheet();
  for (const r of rows1) {
    if (!testRows1.find(tr => tr[1] === r[1])) fail(`Svar ej hittat: ${r[1]}`);
  }
  ok("Verifierade att uppdaterade svar finns i Test-flik");
  // 5) Uppdatera frågor
  const rows2 = items.map(it => [`${it.question} yyy-${it.lang.toLowerCase()}`, it.answer]);
  await appendRowsToTest(rows2);
  ok("16 uppdaterade frågor sparade i Test-flik");
  // 6) Verifiera frågor
  const testRows2 = await readTestSheet();
  for (const r of rows2) {
    if (!testRows2.find(tr => tr[0] === r[0])) fail(`Fråga ej hittad: ${r[0]}`);
  }
  ok("Verifierade att uppdaterade frågor finns i Test-flik");
  // 7+8) FUZZY test
  for (const it of items) {
    const fuzzyQ = it.question.split(" ").reverse().join(" "); // enkel variant
    const questions = (await getFaqByLang(it.lang)).map(f => normalizeMessage(f.question));
    const matches = stringSimilarity.findBestMatch(normalizeMessage(fuzzyQ), questions);
    const reply = (await getFaqByLang(it.lang))[matches.bestMatchIndex].answer;
    logChat(fuzzyQ, it.lang, "FUZZY", reply);
    if (!reply) fail(`Ingen FUZZY match för ${it.lang} :: ${fuzzyQ}`);
  }
  ok("FUZZY frågor hittade svar");
  // 9) Uppdatera FUZZY-svar
  const rows3 = items.map(it => [it.question, `${it.answer} fuzzy-${it.lang.toLowerCase()}`]);
  await appendRowsToTest(rows3);
  ok("16 FUZZY-uppdaterade svar sparade i Test-flik");
  // 10) Verifiera FUZZY-svar
  const testRows3 = await readTestSheet();
  for (const r of rows3) {
    if (!testRows3.find(tr => tr[1] === r[1])) fail(`FUZZY-svar ej hittat: ${r[1]}`);
  }
  ok("Verifierade att FUZZY-svar finns i Test-flik");
  console.log("🟩 Alla tester klara");
  console.log(`📊 Summering: ${mismatchCount} språk-mismatchar hittades`);
}
// --- Main ---
if (!SHEET_ID) throw new Error("SHEET_ID saknas i .env.vercel");
runSuperSuite().catch(err => {
  console.error("💥 Testfel:", err);
  process.exit(1);
});