// lib/faq.js
import { normalizeMessage } from "./utils.js";
import stringSimilarity from "string-similarity";

export const allFaqData = {}; // cache per språk

/**
 * Ladda ALL FAQ-data via en injicerad funktion (från utils.js).
 * Detta undviker cirkulära beroenden.
 */
export async function refreshAllFaqData(loadAllFromUtils) {
  const loaded = await loadAllFromUtils();
  for (const [lang, list] of Object.entries(loaded)) {
    allFaqData[lang] = Array.isArray(list) ? list : [];
  }
  return allFaqData;
}

/** Antal frågor för ett språk */
export function getFaqData(lang = "SE") {
  return (allFaqData[lang] || []).length;
}

/** Lista med frågor/svar för ett språk */
export function getFaqList(lang = "SE") {
  return allFaqData[lang] || [];
}

/**
 * Hitta bästa match i FAQ. Väljer fuzzy om USE_FUZZY=true i .env,
 * annars en enkel heuristik (includes + längdscore).
 */
export function findBestMatch(message, lang = "SE") {
  const faqs = allFaqData[lang] || [];
  if (!faqs.length) return null;

  const msg = normalizeMessage(message);
  const useFuzzy = String(process.env.USE_FUZZY || "").toLowerCase() === "true";

  if (useFuzzy) {
    // 🔎 Fuzzy
    const questions = faqs.map((f) => normalizeMessage(f.question || ""));
    const { bestMatch, bestMatchIndex } = stringSimilarity.findBestMatch(msg, questions);
    const best = faqs[bestMatchIndex];
    return best ? { match: best, score: bestMatch.rating } : null;
  }

  // 🔎 Enkel heuristik (fallback)
  let best = null;
  for (const f of faqs) {
    const q = normalizeMessage(f.question || "");
    if (!q) continue;

    if (msg === q) {
      return { match: f, score: 1.0 }; // perfekt träff
    }

    if (msg.includes(q) || q.includes(msg)) {
      const score = Math.min(msg.length, q.length) / Math.max(msg.length, q.length);
      if (!best || score > best.score) best = { match: f, score };
    }
  }
  return best;
}
