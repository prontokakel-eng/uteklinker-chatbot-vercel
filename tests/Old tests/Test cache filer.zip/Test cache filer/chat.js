import OpenAI from "openai";
import { containsAllowedWord, normalizeMessage } from "./utils.js";
import { findBestMatch } from "./faq.js";

const FAQ_THRESHOLD = 0.85;

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

/**
 * Hanterar inkommande frågor till chat-API
 */
export async function chatHandler(req, res) {
  try {
    const { message, lang = "SE", mode = "STRICT" } = req.body;

    if (!message || typeof message !== "string") {
      console.warn("⚠️ Ogiltig fråga mottagen:", req.body);
      return res.status(400).json({ error: "Ogiltig fråga" });
    }

    console.log("📥 /api/chat kallad. Body:", req.body);
    console.log("🔎 Match mode:", mode);

    // 1) Normalisera
    const normalizedMessage = normalizeMessage(message);
    console.log("✅ normalizedMessage:", normalizedMessage);

    // 2) Validation
    if (!containsAllowedWord(normalizedMessage, lang)) {
      console.log("❌ Validation fail – inga tillåtna ord funna.");
      return res.json({
        reply: "Din fråga är inte relaterad till våra produkter, vänligen omformulera.",
        source: "Validation",
        score: 0,
        normalizedMessage,
      });
    }

    // 3) FAQ-match
    const match = findBestMatch(normalizedMessage, lang);
    if (match) {
      console.log("📚 FAQ-match hittad:", match);
      if (match.score >= FAQ_THRESHOLD) {
        return res.json({
          reply: match.match.answer || "❌ FAQ-svar saknas",
          source: `FAQ (${mode})`,
          score: match.score,
          normalizedMessage,
        });
      } else {
        console.log("ℹ️ FAQ-score under threshold:", match.score);
      }
    } else {
      console.log("ℹ️ Ingen FAQ-match hittad.");
    }

    // 4) Fallback – AI
    console.log("🤖 Anropar OpenAI...");
    const aiResponse = await openai.chat.completions.create({
      model: "gpt-4.0",
      messages: [
        {
          role: "system",
          content: "Du är en hjälpsam kundsupportagent för byggprodukter. Svara kortfattat och tydligt.",
        },
        { role: "user", content: normalizedMessage },
      ],
    });

    const reply = aiResponse.choices[0].message.content;
    console.log("🤖 AI-svar genererat.");

    return res.json({
      reply,
      source: "AI",
      score: 0,
      normalizedMessage,
    });
  } catch (err) {
    console.error("💥 Handler error:", err);
    return res.status(500).json({ error: "Server error" });
  }
}

/**
 * Utility för statistik/debug
 */
export function getFaqData(lang = "SE") {
  return (global.allFaqData?.[lang] || []).length;
}
