// server.js
import dotenv from "dotenv";
dotenv.config();

import express from "express";
import bodyParser from "body-parser";
import path from "path";
import { fileURLToPath } from "url";
import OpenAI from "openai";

// Handlers & helpers
import { chatHandlerExperimental as chatHandler } from "./lib/experimental.js";
import {
  getFaqData as getFaqCount,
  getFaqList,
  refreshAllFaqData,
  allFaqData,
} from "./lib/faq.js";
import { loadAllFaqData, saveAiReply, saveFaqReply } from "./lib/utils.js";

// ESM-safe __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// 🚑 Fix för PowerShell/undici "Expect: 100-continue"
app.use((req, res, next) => {
  if (req.headers["expect"]) {
    console.warn("⚠️ Rensar bort Expect-header:", req.headers["expect"]);
    delete req.headers["expect"];
  }
  next();
});

// 🔹 Serva statiska filer (index.html, css/, js/, bilder, etc.)
app.use(express.static(__dirname));

// Healthcheck
app.get("/healthz", (_, res) => res.status(200).json({ ok: true }));

// Rot – servera index.html
app.get("/", (_req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// -------------------- API -------------------- //

// Antal FAQ-frågor per språk
app.get("/api/faq", async (req, res) => {
  try {
    const lang = (req.query.lang || "SE").toUpperCase();
    const count = getFaqCount(lang);
    res.json({ success: true, lang, count });
  } catch (error) {
    console.error("💥 /api/faq error:", error);
    if (!res.headersSent) res.status(500).json({ success: false, error: error.message });
  }
});

// Full FAQ-data (lista från cache)
app.get("/api/faq-data", async (req, res) => {
  try {
    const lang = (req.query.lang || "SE").toUpperCase();
    const faqs = getFaqList(lang);
    res.json(faqs);
  } catch (error) {
    console.error("💥 /api/faq-data error:", error);
    if (!res.headersSent) res.status(500).json({ error: error.message });
  }
});

// Chat
app.post("/api/chat", async (req, res) => {
  try {
    await chatHandler(req, res);
  } catch (error) {
    console.error("💥 /api/chat error:", error);
    if (!res.headersSent) res.status(500).json({ error: "Fel i /api/chat" });
  }
});

// Spara redigerat/nytt FAQ-svar
app.post("/api/save-faq-reply", async (req, res) => {
  try {
    const { question, reply, lang = "SE" } = req.body || {};
    if (!question || !reply) {
      return res.status(400).json({ success: false, error: "question och reply krävs" });
    }
    await saveFaqReply(question, reply, lang);

    // Uppdatera cachen så posten blir tillgänglig direkt
    if (!allFaqData[lang]) allFaqData[lang] = [];
    allFaqData[lang].push({ question, answer: reply });

    res.json({ success: true });
  } catch (err) {
    console.error("💥 /api/save-faq-reply error:", err);
    if (!res.headersSent) res.status(500).json({ success: false, error: err.message });
  }
});

// Detect language (GPT-4.0 + fail-safe)
app.post("/api/detect-lang", async (req, res) => {
  try {
    const { text } = req.body || {};
    if (!text) return res.status(400).json({ error: "Missing text" });

    let detectedLang = "SE"; // default

    try {
      const prompt = `
Du är en språkdetektor. Identifiera om texten är svenska (SE), engelska (EN), danska (DA) eller tyska (DE).
Svar endast med språkkoden.

Text: """${text}"""
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4.0",
        messages: [{ role: "user", content: prompt }],
        max_tokens: 5,
        temperature: 0,
      });

      const raw = response.choices[0]?.message?.content?.trim().toUpperCase();
      if (["SE", "EN", "DA", "DE"].includes(raw)) {
        detectedLang = raw;
      }
    } catch (apiErr) {
      console.error("💥 GPT detect-lang error:", apiErr);
    }

    return res.status(200).json({ lang: detectedLang });
  } catch (err) {
    console.error("💥 /api/detect-lang fatal error:", err);
    if (!res.headersSent) res.status(500).json({ lang: "SE", error: err.message });
  }
});

// ------------------------------------------------ //

// 🔸 Init – ladda FAQ-cache vid serverstart
await refreshAllFaqData(loadAllFaqData)
  .then(() => console.log("📚 FAQ-data laddades in vid serverstart"))
  .catch((err) => console.error("💥 Kunde inte ladda FAQ-data vid serverstart:", err));

// 🔄 Uppdatera FAQ var 4:e timme
setInterval(async () => {
  try {
    console.log("🔄 Automatisk FAQ-refresh...");
    await refreshAllFaqData(loadAllFaqData);
    console.log("✅ FAQ uppdaterad automatiskt");
  } catch (err) {
    console.error("💥 Misslyckades med automatisk FAQ-refresh:", err);
  }
}, 4 * 60 * 60 * 1000);

// Starta servern
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Servern kör på http://localhost:${PORT}`);
});

// Exportera appen
export default app;
