// chat-ui.js

const messagesDiv = document.getElementById("messages");
const input = document.getElementById("userInput");
const sendButton = document.getElementById("sendButton");
const faqBanner = document.getElementById("faqBanner");
const saveBanner = document.getElementById("saveBanner");
const editContainer = document.getElementById("editContainer");
const editField = document.getElementById("editField");
const saveEditBtn = document.getElementById("saveEditBtn");
const cancelEditBtn = document.getElementById("cancelEditBtn");
const langSelect = document.getElementById("langSelect");
const langBanner = document.getElementById("langBanner");

let editTarget = null;
let lang = "SE"; // default
let lastDetectedLang = null; // 🆕 cache för språkdetektering

// 🔎 Language detection (med cache)
async function detectLanguage(text) {
  try {
    // 🆕 återanvänd cache om den finns
    if (lastDetectedLang) {
      return lastDetectedLang;
    }

    const res = await fetch("/api/detect-lang", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
    });
    const data = await res.json();
    if (data?.lang) {
      lastDetectedLang = data.lang; // uppdatera cache
      return data.lang;
    }
  } catch (err) {
    console.error("❌ Language detection failed:", err);
  }
  return "SE";
}

// 🆕 Visa auto-detekterat språk separat
function showLangBanner(detectedLang) {
  if (!langBanner) return;
  langBanner.textContent = `🌍 Auto-detekterat språk: ${detectedLang}`;
  langBanner.style.display = "block";
  setTimeout(() => {
    langBanner.style.display = "none";
  }, 5000);
}

function showBanner(element, text) {
  if (!element) return;
  element.textContent = text;
  element.style.display = "block";
  setTimeout(() => {
    element.style.display = "none";
  }, 3000);
}

function addMessage(text, sender, source = null) {
  if (!messagesDiv) return;

  const div = document.createElement("div");
  div.classList.add("message", sender);

  const p = document.createElement("p");
  p.textContent = text;
  div.appendChild(p);

  if (source) {
    const small = document.createElement("small");
    small.textContent = `✔️ Källa: ${source}`;
    div.appendChild(small);
  }

  // Inline edit-knapp för FAQ
  if (sender === "faq") {
    const editBtn = document.createElement("button");
    editBtn.textContent = "✏️";
    editBtn.classList.add("inline-edit");
    editBtn.onclick = () => startEdit(div, text);
    div.appendChild(editBtn);
  }

  messagesDiv.appendChild(div);
  messagesDiv.scrollTop = messagesDiv.scrollHeight;
}

function startEdit(div, oldText) {
  editTarget = div.querySelector("p");
  if (editField) editField.value = oldText;
  if (editContainer) editContainer.style.display = "block";
  if (editField) editField.focus();
}

if (cancelEditBtn) {
  cancelEditBtn.addEventListener("click", () => {
    editTarget = null;
    if (editContainer) editContainer.style.display = "none";
  });
}

if (saveEditBtn) {
  saveEditBtn.addEventListener("click", async () => {
    if (!editTarget) return;
    const newText = editField?.value.trim();
    if (!newText) return;

    editTarget.textContent = newText;
    if (editContainer) editContainer.style.display = "none";

    // Spara tillbaka till server
    try {
      const res = await fetch("/api/save-faq-reply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          // OBS: här skickar vi tillbaka *samma text* som både question och reply,
          // eftersom UI:et endast redigerar svaret inline i denna version.
          // (För att stödja separat redigering av fråga/svar behövs UI-ändring.)
          question: editTarget.textContent,
          reply: newText,
          lang,
        }),
      });
      const data = await res.json();
      if (data.success) {
        const saved = document.createElement("div");
        saved.classList.add("inline-saved");
        saved.textContent = "✔️ Sparat";
        editTarget.parentElement.appendChild(saved);
      }
    } catch (err) {
      console.error("❌ Save FAQ reply failed:", err);
    }
  });
}

async function sendMessage(message, language) {
  addMessage(message, "user");

  try {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message, lang: language, mode: "STRICT" }),
    });

    const data = await res.json();

    if (data.source && data.source.startsWith("FAQ")) {
      addMessage(data.reply, "faq", "FAQ – Direkt svar från vår FAQ.");
    } else if (data.source === "AI") {
      addMessage(data.reply, "ai", "OpenAI – Genererat av AI.");
    } else if (data.source === "Validation") {
      addMessage(data.reply, "ai", "Validering.");
    } else {
      addMessage(data.reply || "Inget svar.", "ai");
    }
  } catch (err) {
    console.error("❌ Chat error:", err);
    addMessage("Ett fel inträffade.", "ai");
  }
}

// 🆕 Skicka-knapp (klick) med null-skydd
if (sendButton) {
  sendButton.addEventListener("click", async () => {
    const message = input?.value.trim();
    if (!message) return;

    // 🔎 Auto-detektera språk
    const detected = await detectLanguage(message);
    if (detected) {
      if (detected !== lang) {
        showBanner(faqBanner, `⚠️ Språk ändrades från ${lang} → ${detected}`);
        lang = detected;
        lastDetectedLang = detected; // uppdatera cache
        if (langSelect) langSelect.value = detected;
      }
      showLangBanner(detected);
    }

    await sendMessage(message, lang);
    if (input) input.value = "";
  });
}

// ENTER istället för bara klick på knapp
if (input) {
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      if (sendButton) sendButton.click();
    }
  });
}

if (langSelect) {
  langSelect.addEventListener("change", () => {
    lang = langSelect.value;
    lastDetectedLang = null; // 🆕 rensa cache vid manuellt byte
    showBanner(faqBanner, `🌐 Språk ändrat manuellt till ${lang}`);
  });
}
